module prov.validation {
    requires java.desktop;
    requires prov.jsonld;
    requires prov.model;
    requires org.apache.logging.log4j;
    requires jakarta.xml.bind;
    requires com.fasterxml.jackson.annotation;
    requires com.fasterxml.jackson.core;
    requires com.fasterxml.jackson.databind;
    requires mtj;

    exports org.openprovenance.prov.validation;
}