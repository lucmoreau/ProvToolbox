module prov.validation.test {
    requires junit;
    requires prov.model;

    requires prov.validation;
}